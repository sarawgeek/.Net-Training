﻿using System.ComponentModel.DataAnnotations;

namespace JWTDemo.Models
{
    public class Login
    {
     
        public string UserName { get; set; }
        public string Password { get; set; }

      
    }
}
